from django.conf.urls import url
from . import views
                    
urlpatterns = [
    url(r'^$', views.index),
    url(r'^shows/new$', views.show_form),
    url(r'^shows$', views.shows),
    url(r'^shows/create$', views.create_show),
    url(r'^shows/(?P<show_id>\d+)$', views.show_description),
    url(r'^shows/(?P<show_id>\d+)/edit$', views.edit_show),
    url(r'^shows/(?P<show_id>\d+)/destroy$', views.delete_show),
    url(r'^show/(?P<show_id>\d+)/update$', views.update_show)
]