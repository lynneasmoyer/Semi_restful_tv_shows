from django.shortcuts import render, redirect
from .models import *

def show_form(request):
    if request.method == 'GET':
        return render(request, 'tv_app/index.html')

def index(request):
    return redirect('/shows')

def shows(request):
    context = {
        'shows': Show.objects.all()
    }
    if request.method == 'GET':
        return render(request, 'tv_app/shows.html', context)

def create_show(request):
    if request.method == 'POST':
        new_show = Show.objects.create(title= request.POST['title'], network= request.POST['network'], release_date= request.POST['release_date'])
    return redirect(f'/shows/{new_show.id}')

def show_description(request, show_id):
    context = {
        'show': Show.objects.get(id= show_id),
    }
    if request.method == 'GET':
        return render(request, 'tv_app/view_show.html', context)

def edit_show(request, show_id):
    context = {
        'show': Show.objects.get(id= show_id),
    }
    if request.method == 'GET':
        return render(request, 'tv_app/edit_form.html', context)

def delete_show(request, show_id):
    if request.method == 'GET':
        show = Show.objects.get(id=show_id)
        show.delete()
    return redirect('/shows')

def update_show(request, show_id):
    if request.method == 'POST':
        show = Show.objects.get(id=show_id)
        show.title = request.POST['title']
        show.network = request.POST['network']
        show.release_date = request.POST['release_date']
        show.description = request.POST['description']
        show.save()
    return redirect (f'/shows/{show_id}')